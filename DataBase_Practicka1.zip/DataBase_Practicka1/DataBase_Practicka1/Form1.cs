﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataBase_Practicka1
{
    public partial class Text : Form
    {

        SqlConnection sqlConnection;
        public Text()
        {
            InitializeComponent();
        }
        private async void Text_Load(object sender, EventArgs e)
        {
            string connectionSrting = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\79201\source\repos\DataBase_Practicka1\DataBase_Practicka1\Database.mdf;Integrated Security=True";

            sqlConnection = new SqlConnection(connectionSrting);

            await sqlConnection.OpenAsync();

            SqlDataReader sqlReader = null;

            SqlCommand command = new SqlCommand("SELECT * FROM[Tarifs]",sqlConnection);
            try
            {
                sqlReader = await command.ExecuteReaderAsync();
                while (await sqlReader.ReadAsync())
                {
                    listBox1.Items.Add(Convert.ToString(sqlReader["id"] + "  " + Convert.ToString(sqlReader["Price"]) + " " + Convert.ToString(sqlReader["Speed"])));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), ex.Source.ToString(), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (sqlReader != null)
                    sqlReader.Close();
            }
        }







        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (sqlConnection != null && sqlConnection.State != ConnectionState.Closed)
                sqlConnection.Close();
        }

        private void Text_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (sqlConnection != null && sqlConnection.State != ConnectionState.Closed)
                sqlConnection.Close();
        }

        private async void button1_Click(object sender, EventArgs e)
        // наличия текста в текс боксах 
        {
            if (label8.Visible)
                label8.Visible = false;
            
            if (!string.IsNullOrEmpty(textBox1.Text) && !string.IsNullOrWhiteSpace(textBox1.Text) &&
                !string.IsNullOrEmpty(textBox2.Text) && !string.IsNullOrWhiteSpace(textBox2.Text))
            {
                SqlCommand command = new SqlCommand("INSERT INTO [Tarifs](Price , Speed)VALUES(@Price,@Speed)", sqlConnection);
                command.Parameters.AddWithValue("Price", textBox1.Text);
                command.Parameters.AddWithValue("Speed", textBox2.Text);

                await command.ExecuteNonQueryAsync();
            }
            else
            {
                label8.Visible = true;

                label8.Text = "Поля 'Цена'и 'скорость' должны быть заполнены!";

            }
        }

        private  async void обновитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            SqlDataReader sqlReader = null;

            SqlCommand command = new SqlCommand("SELECT * FROM[Tarifs]", sqlConnection);
            try
            {
                sqlReader = await command.ExecuteReaderAsync();
                while (await sqlReader.ReadAsync())
                {
                    listBox1.Items.Add(Convert.ToString(sqlReader["id"] + "  " + Convert.ToString(sqlReader["Price"]) + " " + Convert.ToString(sqlReader["Speed"])));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), ex.Source.ToString(), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (sqlReader != null)
                    sqlReader.Close();
            }
        }

        private async void button2_Click(object sender, EventArgs e)
            // наличия текста в текс боксах 
        {
            if (label8.Visible)
                label8.Visible = false;

            if (!string.IsNullOrEmpty(textBox3.Text) && !string.IsNullOrWhiteSpace(textBox3.Text) &&
                !string.IsNullOrEmpty(textBox4.Text) && !string.IsNullOrWhiteSpace(textBox4.Text) &&
                !string.IsNullOrEmpty(textBox5.Text) && !string.IsNullOrWhiteSpace(textBox5.Text))
            {
                SqlCommand command = new SqlCommand("UPDATE [Tarifs] SET [Price]=@Price , [Speed]=@Speed WHERE [ID]=@Id",sqlConnection);
                command.Parameters.AddWithValue("Id", textBox5.Text);
                command.Parameters.AddWithValue("Price", textBox4.Text);
                command.Parameters.AddWithValue("Speed", textBox3.Text);

                await command.ExecuteNonQueryAsync();
            }
            else if (!string.IsNullOrEmpty(textBox4.Text) && !string.IsNullOrWhiteSpace(textBox4.Text))
            {
                label9.Visible = true;

                label9.Text = "ID должен быть заполнен!";
            }
            else
            {
                label9.Visible = true;

                label9.Text = "Поля 'Id', 'Цена'и 'скорость' должны быть заполнены!";
            }       
        
        }

        private async void button3_Click(object sender, EventArgs e)
        {
            // наличия текста в текс боксах 
            if (!string.IsNullOrEmpty(textBox6.Text) && !string.IsNullOrWhiteSpace(textBox6.Text))
            {
                SqlCommand command = new SqlCommand("DELETE FROM [Tarifs] WHERE [Id]=@Id", sqlConnection);

                command.Parameters.AddWithValue("Id", textBox6.Text);

                await command.ExecuteNonQueryAsync();
            }
            else
            {
                label10.Visible = true;

                label10.Text = "ID должен быть заполнен!";
            }

                

        }
    }
}
